import React from 'react';

function Farmers() {
  return (
    <div className='home'>
      <h1>Farmers</h1>
    </div>
  );
}

export default Farmers;