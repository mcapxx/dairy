import React from 'react';

function Employees() {
  return (
    <div className='home'>
      <h1>Contact</h1>
    </div>
  );
}

export default Employees;